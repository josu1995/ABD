package laboratorio5.threads;

import java.sql.SQLException;

import laboratorio5.Data;

public class Thread_F  extends Thread {
	String myName="F";
	Data myData1;
	Data myData2;
	public Thread_F(int mode) {
		myData1 = new Data("192.168.56.10","3306","superusuario","josu1995",mode);		
		myData2 = new Data("10.109.188.82","8306","concurrency_control","12345678",mode);
	}
	public void run() {
		int counter1=0;
		int counter2=0;
		Boolean commited;
		
		myData1.syncronize();
		System.out.println("GO"+myName);
		
		while(counter1<Data.NUMBER_OF_ITERATIONS || counter2 < Data.NUMBER_OF_ITERATIONS) {
			if(counter1<Data.NUMBER_OF_ITERATIONS) {
				commited=myData1.procedureF(myName, counter1);
				if(commited==true) {
					counter1++;
				}
			}
			if(counter2<Data.NUMBER_OF_ITERATIONS) {
				commited=myData2.procedureF(myName, counter2);
				if(commited==true) {
					counter2++;
				}
			}
		}
		try {
			myData1.finish();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("finish"+myName);
		
	}
}
