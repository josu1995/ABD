package laboratorio5;

import java.sql.*;
import java.util.concurrent.ThreadLocalRandom;

public class Data {

	private Connection conn;
	private Statement st;
	private String threadName;

	private static final String server = "jdbc:mysql://";

	private String database = "concurrency_control";
	private String table_name = "variables";
	private String name_field = "name";
	private String value_field = "value";

	public static final int NONLOCKING = 0;
	public static final int LOCKING = 1;
	public static final int NUMBER_OF_ITERATIONS = 10;

	public static final int SHARE_LOCKING = LOCKING;
	public static final int EXCLUSIVE_LOCKING = 2 * LOCKING;

	public static final int NUMBER_OF_THREADS = 6;

	private static final String X = "X";
	private static final String Y = "Y";
	private static final String Z = "Z";
	private static final String T = "T";
	private static final String A = "A";
	private static final String B = "B";
	private static final String C = "C";
	private static final String D = "D";
	private static final String E = "E";
	private static final String F = "F";
	private static final String M = "M";

	private int SHARE_MODE;
	private int EXCLUSIVE_MODE;

	public Data(String url, String puerto, String usu, String pass, int pLocking) {
		if (pLocking != Data.LOCKING) {
			SHARE_MODE = NONLOCKING;
			EXCLUSIVE_MODE = NONLOCKING;
		} else {
			SHARE_MODE = SHARE_LOCKING;
			EXCLUSIVE_MODE = EXCLUSIVE_LOCKING;
		}

		// load MySQL driver
		try {
			Class.forName("org.gjt.mm.mysql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.exit(1);
		}

		// open connection
		try {
			conn = DriverManager.getConnection(server + url + ":" + puerto + "/" + database, usu, pass);
			conn.setAutoCommit(false);
			st = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.exit(1);
		}

	}

	private int getValue(int pLockingMode, String pVariable) throws SQLException {
		String mode = "";
		int result = 0;
		if (pLockingMode == SHARE_LOCKING) {
			mode = "LOCK IN SHARE MODE";
		} else if (pLockingMode == EXCLUSIVE_LOCKING) {
			mode = "FOR UPDATE";
		}
		String sql = "SELECT " + value_field + " FROM " + table_name + " WHERE " + name_field + "='" + pVariable + "' "
				+ mode;

		ResultSet res = st.executeQuery(sql);
		res.next();
		result = res.getInt(value_field);
		return result;
	}

	private boolean setValue(int mode, String pVariable, int pValue) throws SQLException {

		String sql = "UPDATE " + table_name + " SET " + value_field + "='" + pValue + "' WHERE " + name_field + "='"
				+ pVariable + "'";
		int rows = st.executeUpdate(sql);

		return rows > 0;
	}

	private void commit() throws SQLException {

		String sql = "COMMIT";
		st.execute(sql);

	}

	private void rollback() {
		try {

			String sql = "ROLLBACK";
			st.execute(sql);

		} catch (SQLException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	private void increaseBarrierValue() {
		try {
			int barrier = getValue(EXCLUSIVE_LOCKING, M);
			setValue(EXCLUSIVE_LOCKING, M, barrier + 1);
			commit();
		} catch (SQLException e) {
			rollback();
		}
	}

	private void decreaseBarrierValue() {
		try {
			int barrier = getValue(EXCLUSIVE_LOCKING, M);
			setValue(EXCLUSIVE_LOCKING, M, (barrier - 1));
			commit();
		} catch (SQLException e) {
			rollback();
		}
	}

	private int getBarrierValue() {
		try {
			int m = getValue(SHARE_LOCKING, M);
			commit();
			return m;
		} catch (SQLException e) {
			rollback();
			return -1;
		}
	}

	public void syncronize() {
		increaseBarrierValue();
		int barrierValue = getBarrierValue();

		while (barrierValue < NUMBER_OF_THREADS) {
			try {
				Thread.sleep(ThreadLocalRandom.current().nextInt(1, 11));
				barrierValue = getBarrierValue();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void finish() throws SQLException {
		decreaseBarrierValue();
	}

	public boolean initializeVariables() {
		try {
			setValue(EXCLUSIVE_MODE, X, 0);
			setValue(EXCLUSIVE_MODE, Y, 0);
			setValue(EXCLUSIVE_MODE, Z, 0);
			setValue(EXCLUSIVE_MODE, T, 0);
			setValue(EXCLUSIVE_MODE, A, 0);
			setValue(EXCLUSIVE_MODE, B, 0);
			setValue(EXCLUSIVE_MODE, C, 0);
			setValue(EXCLUSIVE_MODE, D, 0);
			setValue(EXCLUSIVE_MODE, E, 0);
			setValue(EXCLUSIVE_MODE, F, 0);
			setValue(EXCLUSIVE_MODE, M, 0);
			commit();
			return true;
		} catch (SQLException e) {
			rollback();
			return false;
		}
	}

	public boolean showInitialValues() {
		try {
			System.out.println("Initial value of " + X + ": " + Integer.toString(getValue(SHARE_MODE, X)));
			System.out.println("Initial value of " + Y + ": " + Integer.toString(getValue(SHARE_MODE, Y)));
			System.out.println("Initial value of " + Z + ": " + Integer.toString(getValue(SHARE_MODE, Z)));
			System.out.println("Initial value of " + T + ": " + Integer.toString(getValue(SHARE_MODE, T)));
			System.out.println("Initial value of " + A + ": " + Integer.toString(getValue(SHARE_MODE, A)));
			System.out.println("Initial value of " + B + ": " + Integer.toString(getValue(SHARE_MODE, B)));
			System.out.println("Initial value of " + C + ": " + Integer.toString(getValue(SHARE_MODE, C)));
			System.out.println("Initial value of " + D + ": " + Integer.toString(getValue(SHARE_MODE, D)));
			System.out.println("Initial value of " + E + ": " + Integer.toString(getValue(SHARE_MODE, E)));
			System.out.println("Initial value of " + F + ": " + Integer.toString(getValue(SHARE_MODE, F)));
			commit();
			return true;
		} catch (SQLException e) {
			rollback();
			return false;
		}
	}

	public boolean showFinalValues() {
		int barrierValue = getBarrierValue();

		while (barrierValue < 1) {
			try {
				Thread.sleep(ThreadLocalRandom.current().nextInt(1, 11));
				barrierValue = getBarrierValue();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		while (barrierValue > 0) {
			try {
				Thread.sleep(ThreadLocalRandom.current().nextInt(1, 11));
				barrierValue = getBarrierValue();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		try {
			System.out.println("The Final value of the variable X is " + getValue(NONLOCKING, X));
			System.out.println("The Final value of the variable Y is " + getValue(NONLOCKING, Y));
			System.out.println("The Final value of the variable Z is " + getValue(NONLOCKING, Z));
			System.out.println("The Final value of the variable T is " + getValue(NONLOCKING, T));
			System.out.println("The Final value of the variable A is " + getValue(NONLOCKING, A));
			System.out.println("The Final value of the variable B is " + getValue(NONLOCKING, B));
			System.out.println("The Final value of the variable C is " + getValue(NONLOCKING, C));
			System.out.println("The Final value of the variable D is " + getValue(NONLOCKING, D));
			System.out.println("The Final value of the variable E is " + getValue(NONLOCKING, E));
			System.out.println("The Final value of the variable F is " + getValue(NONLOCKING, F));
			System.out.println("The Final value of the variable M is " + getValue(NONLOCKING, M));

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean procedureA(String myName, int counter1) {
		threadName = myName;
		try {
			int x = getValue(EXCLUSIVE_MODE, X);
			x++;
			setValue(EXCLUSIVE_MODE, X, x);
			int t = getValue(EXCLUSIVE_MODE, T);
			int a = getValue(EXCLUSIVE_MODE, A);
			int y = getValue(SHARE_MODE, Y);
			t += y;
			a += y;
			setValue(EXCLUSIVE_MODE, T, t);
			setValue(EXCLUSIVE_MODE, A, a);

			commit();
			return true;
		} catch (SQLException e) {
			rollback();
			return false;
		}
	}

	public boolean procedureB(String myName, int counter1) {
		threadName = myName;
		try {
			int y = getValue(EXCLUSIVE_MODE, Y);
			y++;
			setValue(EXCLUSIVE_MODE, Y, y);
			int t = getValue(EXCLUSIVE_MODE, T);
			int b = getValue(EXCLUSIVE_MODE, B);
			int z = getValue(SHARE_MODE, Z);
			t += z;
			b += z;
			setValue(EXCLUSIVE_MODE, T, t);
			setValue(EXCLUSIVE_MODE, B, b);

			commit();
			return true;
		} catch (SQLException e) {
			rollback();
			return false;
		}
	}

	public boolean procedureC(String myName, int counter1) {
		threadName = myName;
		try {
			int z = getValue(EXCLUSIVE_MODE, Z);
			z++;
			setValue(EXCLUSIVE_MODE, Z, z);
			int t = getValue(EXCLUSIVE_MODE, T);
			int c = getValue(EXCLUSIVE_MODE, C);
			int x = getValue(SHARE_MODE, X);
			t += x;
			c += x;
			setValue(EXCLUSIVE_MODE, T, t);
			setValue(EXCLUSIVE_MODE, C, c);

			commit();
			return true;
		} catch (SQLException e) {
			rollback();
			return false;
		}
	}

	public boolean procedureD(String myName, int counter1) {
		threadName = myName;
		try {
			int t = getValue(EXCLUSIVE_MODE, T);
			int d = getValue(EXCLUSIVE_MODE, D);
			int z = getValue(SHARE_MODE, Z);
			t += z;
			d += z;
			setValue(EXCLUSIVE_MODE, T, t);
			setValue(EXCLUSIVE_MODE, D, d);
			int x = getValue(EXCLUSIVE_MODE, X);
			x -= 1;
			setValue(EXCLUSIVE_MODE, X, x);

			commit();
			return true;
		} catch (SQLException e) {
			rollback();
			return false;
		}
	}

	public boolean procedureE(String myName, int counter1) {
		threadName = myName;
		try {
			int t = getValue(EXCLUSIVE_MODE, T);
			int e = getValue(EXCLUSIVE_MODE, E);
			int x = getValue(SHARE_MODE, X);
			t += x;
			e += x;
			setValue(EXCLUSIVE_MODE, T, t);
			setValue(EXCLUSIVE_MODE, E, e);
			int y = getValue(EXCLUSIVE_MODE, Y);
			y -= 1;
			setValue(EXCLUSIVE_MODE, Y, y);

			commit();
			return true;
		} catch (SQLException e) {
			rollback();
			return false;
		}
	}

	public boolean procedureF(String myName, int counter1) {
		threadName = myName;
		try {
			int t = getValue(EXCLUSIVE_MODE, T);
			int f = getValue(EXCLUSIVE_MODE, F);
			int y = getValue(SHARE_MODE, Y);
			t += y;
			f += y;
			setValue(EXCLUSIVE_MODE, T, t);
			setValue(EXCLUSIVE_MODE, F, f);
			int z = getValue(EXCLUSIVE_MODE, Z);
			z -= 1;
			setValue(EXCLUSIVE_MODE, Z, z);

			commit();
			return true;
		} catch (SQLException e) {
			rollback();
			return false;
		}
	}

}
