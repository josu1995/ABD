package laboratorio5;

import laboratorio5.threads.*;

public class Main {

	static final int mode = Data.LOCKING;
	


	public static void main(String[] args) {
     
		Data mainData = new Data("192.168.56.10","3306","superusuario","josu1995",mode);		
		Data mainData1 = new Data("10.109.188.82","8306","concurrency_control","12345678",mode);
		
		Thread_A threadA = new Thread_A(mode);
		Thread_B threadB = new Thread_B(mode);
		Thread_C threadC = new Thread_C(mode);
		//Thread_D threadD = new Thread_D(mode);
		//Thread_E threadE = new Thread_E(mode);
		//Thread_F threadF = new Thread_F(mode);

		mainData.initializeVariables();
		mainData1.initializeVariables();
		mainData.showInitialValues();
		mainData1.showInitialValues();

		new Thread(threadA).start();
		new Thread(threadB).start();
		new Thread(threadC).start();
		//new Thread(threadD).start();
		//new Thread(threadE).start();
		//new Thread(threadF).start();

		mainData.showFinalValues();

	}

}
